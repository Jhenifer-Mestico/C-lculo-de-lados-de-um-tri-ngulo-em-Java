/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tresareas;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class Tresareas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        float AT,A1,A2,A3, ladoina, ladoinb, ladoinferior;
    Scanner inputData = new Scanner(System.in);
    System.out.println("Digite o valor do lado A:");
    A1 = inputData.nextFloat(); 
    System.out.println("Digite o valor do lado inferior A:");
    ladoina = inputData.nextFloat();
    
    System.out.println("Digite o valor do lado B:");
    A2 = inputData.nextFloat(); 
    System.out.println("Digite o valor do lado inferior B:");
    ladoinb = inputData.nextFloat();
    
    System.out.println("Digite o valor do lado D:");
    A3 = inputData.nextFloat(); 
    
    AT = A1+A2+A3;
    System.out.println("Área Total é:" + AT );
    
    ladoinferior = ladoina*ladoinb;
    System.out.println("Área Total dos lados são:" + ladoinferior );
    
    }
    
}
